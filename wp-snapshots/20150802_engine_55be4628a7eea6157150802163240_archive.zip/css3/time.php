<?php 
 	echo date('Y-m-d H:i:s/e');
?>